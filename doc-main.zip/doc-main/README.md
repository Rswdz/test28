# Awesome-jianso



![header_1.png](img/header_1.png)

> An awesome project.|收集有意思的项目

# 



-------

# 日常

------



calibre-web一个在线图书馆,目前只支持epub和PDF

[awesome-jianso/calibre-web: Web app for browsing, reading and downloading eBooks stored in a Calibre database](https://github.com/awesome-jianso/calibre-web)





# 算法

------

goac

[awesome-jianso/goa.c: 📚 中文书籍：数据结构和算法（Golang实现）Chinese Book](https://github.com/awesome-jianso/goa.c/tree/master)





# Golang

---------



-
